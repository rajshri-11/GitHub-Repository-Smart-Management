package com.login.entity;

public enum UserType {
    ADMIN, STUDENT
}
